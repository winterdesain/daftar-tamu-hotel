<?php $__env->startSection('content'); ?>
<h2>Customers</h2>
<a href="<?php echo e(route('customers.create')); ?>">Tambah Customer</a>
<table border="1" cellpadding="6" cellspacing="0">
    <tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Actions</th></tr>
    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($c->id); ?></td>
        <td><?php echo e($c->name); ?></td>
        <td><?php echo e($c->email); ?></td>
        <td><?php echo e($c->phone); ?></td>
        <td>
            <a href="<?php echo e(route('customers.edit', $c->id)); ?>">Edit</a>
            <form action="<?php echo e(route('customers.destroy', $c->id)); ?>" method="POST" style="display:inline">
                <?php echo csrf_field(); ?>
                <button type="submit">Delete</button>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Winter\OneDrive\Pictures\Daftar Tamu hotel\crm_laravel_project\resources\views\customers\index.blade.php ENDPATH**/ ?>