<?php $__env->startSection('content'); ?>
<h2><?php echo e($customer ? 'Edit' : 'Tambah'); ?> Customer</h2>
<form method="POST" action="<?php echo e($customer ? route('customers.update', $customer->id) : route('customers.store')); ?>">
    <?php echo csrf_field(); ?>
    <label>Name</label><br>
    <input type="text" name="name" value="<?php echo e($customer->name ?? ''); ?>" required><br>
    <label>Email</label><br>
    <input type="email" name="email" value="<?php echo e($customer->email ?? ''); ?>"><br>
    <label>Phone</label><br>
    <input type="text" name="phone" value="<?php echo e($customer->phone ?? ''); ?>"><br>
    <label>Address</label><br>
    <textarea name="address"><?php echo e($customer->address ?? ''); ?></textarea><br>
    <button type="submit">Simpan</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Winter\OneDrive\Pictures\Daftar Tamu hotel\crm_laravel_project\resources\views\customers\form.blade.php ENDPATH**/ ?>