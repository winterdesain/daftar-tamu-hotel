<?php $__env->startSection('content'); ?>
<h2>Login</h2>
<?php if(session('error')): ?>
    <div style="color:red"><?php echo e(session('error')); ?></div>
<?php endif; ?>
<form method="POST" action="<?php echo e(route('auth.login.post')); ?>">
    <?php echo csrf_field(); ?>
    <label>Email</label><br>
    <input type="email" name="email" required><br>
    <label>Password</label><br>
    <input type="password" name="password" required><br>
    <button type="submit">Login</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Winter\OneDrive\Pictures\Daftar Tamu hotel\crm_laravel_project\resources\views\auth\login.blade.php ENDPATH**/ ?>